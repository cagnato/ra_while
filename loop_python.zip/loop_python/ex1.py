# Inicio do código
print("Bem-vindo ao loop de tabuada")

# Campo para o usuário inserir o número do qual deseja verificar a tabuada
numero = int(input("Digite um número para ver sua tabuada: "))

# Loop para começar a tabuada
contador = 0
while contador <= 10: #Limitando a tabuada para 10
 print(f"O número {contador} multiplicado por {numero} é {numero * contador}") # Retorna a tabuada do numero escolhido até 10
 contador = contador + 1 #acrescenta +1 para toda verificação do while, para evitar o loop de 0 infinito