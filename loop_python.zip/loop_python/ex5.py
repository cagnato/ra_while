contador = 0
pares = 0
impares = 0

while contador < 10:
    numero = int(input("digite um número: "))

    if numero % 2 == 0:
        pares += 1
    else:
        impares += 1

    contador += 1

print (f"Pares = {pares}")
print (f"Impares = {impares}")