print("Bem vindo ao somatório")

numero = int(input("Insira a quantidade de números que deseja somar: "))

soma = 0
contador = 1

while contador <= numero:
    soma += contador
    contador += 1

print(soma)