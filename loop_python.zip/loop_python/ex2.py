# Começando o código
print("Olá, seja bem vindo ao registro de notas!")

# Campo para o usuário inserir nota
nota = float(input("Insira sua nota: "))

# Loop para verificar a nota inserida para o usuário

while nota < 7 and nota >= 0: #mantém o loop até o momento da nota atingir 7
    print("Nota inválida, insira novamente")
    nota = float(input("Insira sua nota: "))
    # verifica a nova nota
    if nota >= 7 and nota <= 10: 
        print("Parabés, você passou")
else:
    print("Nota inválida!")
