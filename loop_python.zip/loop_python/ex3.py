print("Bem vindo ao código batuta das médias")


soma = 0
contador = 0

while contador != -1:
    numero = int(input("Insira um número: "))
    
    if numero == -1:
        break
   
    soma += numero
    contador += 1
print(soma / contador)